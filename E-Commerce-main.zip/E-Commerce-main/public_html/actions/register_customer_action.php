<?php
/**
 * Public wrapper for register_customer_action.php
 * Keeps the same behavior as the root-level action but makes it reachable
 * from code running under the `public_html` document root.
 */

require_once __DIR__ . '/../../actions/register_customer_action.php';

// End of wrapper
